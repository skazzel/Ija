package sample;

import java.util.List;

/**Reprezentuje data, se kterými se dále pracuje a vykreslují se.
 * Jedná se o data o koordinátech a vozidla
 * @author Matěj Krátký, Petr Červinka
 */

public class Data {
    private List<Coordinate> coordinate;
    private List<Vehicle> vehicle;

    public Data() {

    }

    public Data(List<Coordinate> coordinate, List<Vehicle> vehicle) {
        this.coordinate = coordinate;
        this.vehicle = vehicle;
    }

    /**
     * Vrátí list koordinátů.
     * @return list koordinátů.
     */
    public List<Coordinate> getCoordinate() {
        return coordinate;
    }

    /**
     * Vrátí list pozic a rychlostí vozidla.
     * @return List vozidel.
     */
    public List<Vehicle> getVehicle() {
        return vehicle;
    }

    @Override
    public String toString() {
        return "Data{" +
                "coordinate=" + coordinate +
                ", vehicle=" + vehicle +
                '}';
    }
}
