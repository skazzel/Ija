/*
 * Projekt na IJA 2019/2020.
 * Matěj Krátký - xkratk17
 * Petr Červika - xcervi24
 */

package sample;


import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;


import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Time;
import java.time.LocalTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class Main extends Application {

    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("sample.fxml"));
        BorderPane root = loader.load();
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();

        loader.getController();

        Controller controller = loader.getController();
        List<drawable> stopky = new ArrayList<>();
        List<Stop> stopky1 = new ArrayList<>();
        List<Stop> stopky2 = new ArrayList<>();
        List<Stop> stopky3 = new ArrayList<>();
        List<drawable> ulice = new ArrayList<>();
        List<drawable> ulice1 = new ArrayList<>();
        List<drawable> ulice2 = new ArrayList<>();
        List<drawable> ulice3 = new ArrayList<>();
        List<drawable> auta1 = new ArrayList<>();
        List<drawable> auta2 = new ArrayList<>();
        List<drawable> auta3 = new ArrayList<>();
        List<String> posi_list = new ArrayList<>();
        List<Coordinate> coordinates = new ArrayList<>();
        List<Coordinate> coordinatess = new ArrayList<>();
        List<Coordinate> coordinatesss = new ArrayList<>();
        LocalTime time = LocalTime.now();
        drawable au;
        Color[] colors = new Color[] {Color.BLACK, Color.GREEN};
        Color[] colors1 = new Color[] {Color.BLACK, Color.PURPLE};
        Color[] colors2 = new Color[] {Color.BLACK, Color.ORANGE};
        int pocitadlo = 0;
        AtomicInteger cislo = new AtomicInteger();
        Vehicle vehicle;

        try {
            String line = null;
            BufferedReader reader = new BufferedReader(new FileReader("./data/line1.txt"));
            while ((line = reader.readLine()) != null) {
                String[] p_line = line.split(":", 2);
                if (p_line[0].equals("coordinates")) {
                    pocitadlo++;
                    posi_list.add(p_line[1]);
                    //System.out.println(pocitadlo);
                    String[] splitted_line = p_line[1].split(",", 5);
                    coordinates.add(new Coordinate(Integer.parseInt(splitted_line[1]) ,Integer.parseInt(splitted_line[2])));
                    Street street = new Street(splitted_line[0], new Coordinate(Integer.parseInt(splitted_line[1]), Integer.parseInt(splitted_line[2])), new Coordinate(Integer.parseInt(splitted_line[3]), Integer.parseInt(splitted_line[4])));
                    ulice.add(street);
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        try {
            String line = null;
            BufferedReader reader = new BufferedReader(new FileReader("./data/line2.txt"));
            while ((line = reader.readLine()) != null) {
                String[] p_line = line.split(":", 2);
                if (p_line[0].equals("coordinates")) {
                    pocitadlo++;
                    posi_list.add(p_line[1]);
                    //System.out.println(pocitadlo);
                    String[] splitted_line = p_line[1].split(",", 5);
                    coordinatess.add(new Coordinate(Integer.parseInt(splitted_line[1]) ,Integer.parseInt(splitted_line[2])));
                    Street street = new Street(splitted_line[0], new Coordinate(Integer.parseInt(splitted_line[1]), Integer.parseInt(splitted_line[2])), new Coordinate(Integer.parseInt(splitted_line[3]), Integer.parseInt(splitted_line[4])));
                    ulice2.add(street);
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        try {
            String line = null;
            BufferedReader reader = new BufferedReader(new FileReader("./data/line3.txt"));
            while ((line = reader.readLine()) != null) {
                String[] p_line = line.split(":", 2);
                if (p_line[0].equals("coordinates")) {
                    pocitadlo++;
                    posi_list.add(p_line[1]);
                    //System.out.println(pocitadlo);
                    String[] splitted_line = p_line[1].split(",", 5);
                    coordinatesss.add(new Coordinate(Integer.parseInt(splitted_line[1]) ,Integer.parseInt(splitted_line[2])));
                    Street street = new Street(splitted_line[0], new Coordinate(Integer.parseInt(splitted_line[1]), Integer.parseInt(splitted_line[2])), new Coordinate(Integer.parseInt(splitted_line[3]), Integer.parseInt(splitted_line[4])));
                    ulice3.add(street);
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        try {
            String line = null;
            BufferedReader reader = new BufferedReader(new FileReader("./data/data.txt"));
            while ((line = reader.readLine()) != null) {
                String[] p_line = line.split(":", 2);
                //System.out.println(line);
                // nacteme ze souboru souradnice a budeme je prirazovat do cyklu a jakmile to skonci tak se tam priradi dalsi
               /* if (p_line[0].equals("coordinates")) {
                    pocitadlo++;
                    posi_list.add(p_line[1]);
                    //System.out.println(pocitadlo);
                    String[] splitted_line = p_line[1].split(",", 5);
                    Street street = new Street(new Coordinate(Integer.parseInt(splitted_line[1]), Integer.parseInt(splitted_line[2])), new Coordinate(Integer.parseInt(splitted_line[3]), Integer.parseInt(splitted_line[4])));
                    ulice.add(street);
                } */if (p_line[0].equals("stops1")) {
                    //System.out.println(p_line[1]);
                    String[] splitted_line = p_line[1].split(",", 3);
                    //System.out.println(splitted_line[0]);
                    Stop stop = new Stop(splitted_line[2], new Coordinate(Integer.parseInt(splitted_line[0]), Integer.parseInt(splitted_line[1])), "orange", primaryStage);
                    stopky1.add(stop);
                    stopky.add(stop);
                    //System.out.println(stop.getCircle());
                    stop.getCircle().setOnMouseClicked(new EventHandler<MouseEvent>() {
                        @Override
                        public void handle(MouseEvent mouseEvent) {
                            //System.out.println("ahoj");
                            Platform.runLater(() -> {
                                try {
                                    if (cislo.get() < ((colors.length) - 1)) {
                                        cislo.getAndIncrement();
                                    }
                                    else {
                                        cislo.set(0);
                                    }
                                    int i = cislo.intValue();
                                    stop.getCircle().setFill(colors2[i]);
                                    controller.napis11.setText("nazev stopky: " + splitted_line[2] + ", lezi na lince 1");
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            });
                        }
                    });
                } else if (p_line[0].equals("stops2")) {
                    //System.out.println(p_line[1]);
                    String[] splitted_line = p_line[1].split(",", 3);
                    //System.out.println(splitted_line[0]);
                    Stop stop = new Stop(splitted_line[2], new Coordinate(Integer.parseInt(splitted_line[0]), Integer.parseInt(splitted_line[1])), "purple", primaryStage);
                    stopky2.add(stop);
                    stopky.add(stop);
                    stop.getCircle().setOnMouseClicked(new EventHandler<MouseEvent>() {
                        @Override
                        public void handle(MouseEvent mouseEvent) {
                            //System.out.println("ahoj");
                            Platform.runLater(() -> {
                                try {
                                    if (cislo.get() < ((colors.length) - 1)) {
                                        cislo.getAndIncrement();
                                    }
                                    else {
                                        cislo.set(0);
                                    }
                                    int i = cislo.intValue();
                                    stop.getCircle().setFill(colors1[i]);
                                    controller.napis11.setText("nazev stopky: " + splitted_line[2] + ", lezi na lince 2");
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            });
                        }
                    });
                } else if (p_line[0].equals("stops3")) {
                    //System.out.println(p_line[1]);
                    String[] splitted_line = p_line[1].split(",", 3);
                    //System.out.println(splitted_line[0]);
                    Stop stop = new Stop(splitted_line[2], new Coordinate(Integer.parseInt(splitted_line[0]), Integer.parseInt(splitted_line[1])), "green", primaryStage);
                    stopky3.add(stop);
                    stopky.add(stop);
                    stop.getCircle().setOnMouseClicked(new EventHandler<MouseEvent>() {
                        @Override
                        public void handle(MouseEvent mouseEvent) {
                            Platform.runLater(() -> {
                                try {
                                    if (cislo.get() < ((colors.length) - 1)) {
                                        cislo.getAndIncrement();
                                    }
                                    else {
                                        cislo.set(0);
                                    }
                                    int i = cislo.intValue();
                                    stop.getCircle().setFill(colors[i]);
                                    controller.napis11.setText("nazev stopky: " + splitted_line[2] + ", lezi na lince 3");

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            });
                        }
                    });
                }
                //System.out.println(coordinates);

                Vehicle vehicle1 = new Vehicle("Auto1", coordinates.get(0),8, new Path(Arrays.asList(
                        new Coordinate(coordinates.get(0).getX(),coordinates.get(0).getY()),
                        new Coordinate(coordinates.get(1).getX(),coordinates.get(1).getY()),
                        new Coordinate(coordinates.get(2).getX(),coordinates.get(2).getY()),
                        new Coordinate(coordinates.get(3).getX(),coordinates.get(3).getY()),
                        new Coordinate(coordinates.get(4).getX(),coordinates.get(4).getY()),
                        new Coordinate(coordinates.get(5).getX(),coordinates.get(5).getY()),
                        new Coordinate(coordinates.get(6).getX(),coordinates.get(6).getY()),
                        new Coordinate(coordinates.get(7).getX(),coordinates.get(7).getY()),
                        new Coordinate(coordinates.get(8).getX(),coordinates.get(8).getY()),
                        new Coordinate(coordinates.get(9).getX(),coordinates.get(9).getY()),
                        new Coordinate(coordinates.get(10).getX(),coordinates.get(10).getY()),
                        new Coordinate(coordinates.get(11).getX(),coordinates.get(11).getY())
                )), stopky1);
                vehicle1.getCircle().setOnMouseClicked(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent mouseEvent) {
                        Platform.runLater(() -> {
                            try {
                                controller.napis11.setText("Auto: " + "Auto1" + ", jede po lince 1");
                                //System.out.println("ahoj");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        });
                    }
                });
                auta1.add(vehicle1);

                Vehicle auto = new Vehicle("Auto2", coordinates.get(0),8, new Path(Arrays.asList(
                        new Coordinate(coordinatess.get(0).getX(),coordinatess.get(0).getY()),
                        new Coordinate(coordinatess.get(1).getX(),coordinatess.get(1).getY()),
                        new Coordinate(coordinatess.get(2).getX(),coordinatess.get(2).getY()),
                        new Coordinate(coordinatess.get(3).getX(),coordinatess.get(3).getY()),
                        new Coordinate(coordinatess.get(4).getX(),coordinatess.get(4).getY()),
                        new Coordinate(coordinatess.get(5).getX(),coordinatess.get(5).getY()),
                        new Coordinate(coordinatess.get(6).getX(),coordinatess.get(6).getY()),
                        new Coordinate(coordinatess.get(7).getX(),coordinatess.get(7).getY()),
                        new Coordinate(coordinatess.get(8).getX(),coordinatess.get(8).getY()),
                        new Coordinate(coordinatess.get(9).getX(),coordinatess.get(9).getY()),
                        new Coordinate(coordinatess.get(10).getX(),coordinatess.get(10).getY()),
                    new Coordinate(coordinatess.get(11).getX(),coordinatess.get(11).getY())
                )), stopky2);
                auto.getCircle().setOnMouseClicked(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent mouseEvent) {
                        Platform.runLater(() -> {
                            try {
                                controller.napis11.setText("Auto: " + "Auto2" + ", jede po lince 2");
                                //System.out.println("ahoj");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        });
                    }
                });
                auta2.add(auto);

                Vehicle auticko = new Vehicle("Auto3", coordinates.get(0),8, new Path(Arrays.asList(
                        new Coordinate(coordinatesss.get(0).getX(),coordinatesss.get(0).getY()),
                        new Coordinate(coordinatesss.get(1).getX(),coordinatesss.get(1).getY()),
                        new Coordinate(coordinatesss.get(2).getX(),coordinatesss.get(2).getY()),
                        new Coordinate(coordinatesss.get(3).getX(),coordinatesss.get(3).getY()),
                        new Coordinate(coordinatesss.get(4).getX(),coordinatesss.get(4).getY()),
                        new Coordinate(coordinatesss.get(5).getX(),coordinatesss.get(5).getY()),
                        new Coordinate(coordinatesss.get(6).getX(),coordinatesss.get(6).getY()),
                        new Coordinate(coordinatesss.get(7).getX(),coordinatesss.get(7).getY()),
                        new Coordinate(coordinatesss.get(8).getX(),coordinatesss.get(8).getY()),
                        new Coordinate(coordinatesss.get(9).getX(),coordinatesss.get(9).getY()),
                        new Coordinate(coordinatesss.get(10).getX(),coordinatesss.get(10).getY()),
                        new Coordinate(coordinatesss.get(11).getX(),coordinatesss.get(11).getY()),
                        new Coordinate(coordinatesss.get(12).getX(),coordinatesss.get(12).getY()),
                        new Coordinate(coordinatesss.get(13).getX(),coordinatesss.get(13).getY())
                )), stopky3);
                auticko.getCircle().setOnMouseClicked(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent mouseEvent) {
                        Platform.runLater(() -> {
                            try {
                                controller.napis11.setText("Auto: " + "Auto3" + ", jede po lince 3");
                                //System.out.println("ahoj");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        });
                    }
                });
                auta3.add(auticko);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        controller.setElements2(ulice);
        controller.setElements20(ulice2);
        controller.setElements21(ulice3);
        controller.setElements3(stopky);
        controller.setElements(auta1);
        controller.setElementss(auta2);
        controller.setElementsss(auta3);

    }
}