package sample;

import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

/**Reprezentuje třídu, která pracuje s GUI a zapisuje do něj.
 * @author Matěj Krátký, Petr Červinka
 */

public class Controller {
    public Label napis1;
    public AnchorPane spodek;

    public Label napis11;
    public Label napis12;
    public Label napis13;
    public Button button1;
    public Button button2;
    public Button button3;
    public TextField Cas;
    public Button buttonTime;
    public Button buttonZpomaleni;
    public TextField zpomaleni;
    public TextField zpomal;
    @FXML
    private Pane content;

    @FXML
    private TextField TimeScale;
    // list elementu, ktere zobrazujeme na mapu
    private List<drawable> elements = new ArrayList<>();
    private List<TimeUpdate> streets = new ArrayList<>();
    private List<drawable> ulice = new ArrayList<>();
    private List<TimeUpdate> cars = new ArrayList<>();
    private List<TimeUpdate> objezd = new ArrayList<>();
    private List<TimeUpdate> stops = new ArrayList<>();
    private List<String> times = new ArrayList<>();
    public Timer timer;
    private float scale;
    private String cas;
    TimeUpdate stop;
    private LocalTime time = LocalTime.now();
    AtomicInteger hodina = new AtomicInteger();
    AtomicInteger minuta = new AtomicInteger();
    javafx.scene.paint.Color color;
    javafx.scene.paint.Color[] colors = new javafx.scene.paint.Color[] {javafx.scene.paint.Color.BLACK, javafx.scene.paint.Color.RED};
    javafx.scene.paint.Color[] colors1 = new javafx.scene.paint.Color[] {javafx.scene.paint.Color.BLACK, javafx.scene.paint.Color.RED};
    AtomicInteger cislo = new AtomicInteger();

    /**
     * Zvětšuje a zmenšuje mapu.
     * @param event událost(scroll).
     */

    @FXML
    private void onZoom (ScrollEvent event) {
        event.consume();
        double zoom = event.getDeltaY() > 0 ? 1.1 : 0.9;
        content.setScaleX(zoom * content.getScaleX());
        content.setScaleY(zoom * content.getScaleY());
    }

    public void chooseTime() {
        String cas = Cas.getText();
        String[]pole_cas = cas.split(":", 2);
        try {
            hodina.set(Integer.parseInt(pole_cas[0]));
            minuta.set(Integer.parseInt(pole_cas[1]));
        } catch (Exception e) {
            e.printStackTrace();
        }
        timer = new Timer(false);
        AtomicReference<Float> sc = new AtomicReference<>(getScale());
        AtomicReference<Float> sc_remembered = new AtomicReference<>(getScale());
        sc_remembered = sc;
        if (sc.get() == 0) {
            sc.set((float) 1);
            sc_remembered = sc;
        }
        timer.scheduleAtFixedRate(new TimerTask() {
            // kazdou sekundu to bude volat run()
            @Override
            public void run() {
                Platform.runLater(() -> {

                    try {
                        //System.out.println(streets);
                        if (Integer.parseInt(pole_cas[0]) >= 0 || Integer.parseInt(pole_cas[0]) <= 23) {
                            minuta.getAndIncrement();
                            if (minuta.intValue() > 59) {
                                minuta.set(0);
                                hodina.getAndIncrement();
                            }
                            if (hodina.intValue() > 23) {
                                hodina.set(0);
                            }
                            //System.out.println(hodina + ":" + minuta);
                            setCas(hodina + ":" + minuta);
                        }
                        else {
                            Alert alert = new Alert(Alert.AlertType.ERROR, "Zadany cas neexistuje!");
                            alert.showAndWait();
                            return;
                        }

                        for (drawable ulice : ulice) {
                            ((Street)ulice).getLine().setOnMouseClicked(new EventHandler<MouseEvent>() {
                                @Override
                                public void handle(MouseEvent mouseEvent) {
                                    //System.out.println("ahoj");
                                    Platform.runLater(() -> {
                                        try {
                                            if (cislo.get() < ((colors.length) - 1)) {
                                                cislo.getAndIncrement();
                                                ((Street)ulice).getLine().setStrokeWidth(2);
                                            }
                                            else {
                                                cislo.set(0);
                                                ((Street)ulice).getLine().setStrokeWidth(1);
                                            }
                                            int i = cislo.intValue();
                                            ((Street)ulice) .getLine().setStroke(colors[i]);
                                            if (colors[i] == javafx.scene.paint.Color.RED) {
                                                System.out.println(ulice);
                                                buttonZpomaleni.setOnMouseClicked(new EventHandler<MouseEvent>() {
                                                    @Override
                                                    public void handle(MouseEvent mouseEvent) {
                                                        Platform.runLater(() -> {
                                                            try {
                                                                sc.set(Float.parseFloat(zpomal.getText()));
                                                                System.out.println(sc);
                                                            } catch (Exception e) {
                                                                e.printStackTrace();
                                                            }
                                                        });
                                                    }
                                                });
                                            }
                                            else {
                                                //sc = sc_remembered;
                                                ((Street)ulice).getLine().setStrokeWidth(1);
                                            }
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    });
                                }
                            });
                        }
                        for (TimeUpdate update : cars) {
                            update.update(time);
                        }
                        for (TimeUpdate update : streets) {
                            //System.out.println(time);
                            //label1.setText("wtf");
                            //System.out.println(((Street)update).list_lineColor);
                            update.update(time);
                        }
                        for (TimeUpdate update : stops) {
                            //System.out.println(update);
                            //label1.setText("wtf");
                            update.update(time);
                        }
                        System.out.println(sc);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }
        }, 0, (long) (1000/*tohleyvetsitkdzy*/ / sc.get()));
    }

    public void setCas(String cas) {
        this.cas = cas;
    }

    public String getCas() {
        return cas;
    }

    public List<TimeUpdate> getCars() {
        return cars;
    }

    public void zpomalCas(MouseEvent mouseEvent) {

    }

    /**
     * Práce s časem v GUI.
     */

    @FXML
    private void onTimeScaleChange() {
        try {
            float scale = Float.parseFloat(TimeScale.getText());
            napis1.textProperty().set("Rychlost similace: " + (int)scale + "x");
            //napis11.textProperty().set("Rychlost similace: " + (int)scale + "x");
            if (scale <= 0) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Zvolena hodnota musi byt kladne cislo!");
                alert.showAndWait();
                return;
            }
            //timer.cancel();
            setScale(scale);
            //startTime(scale);
        }
        catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Zvolena hodnota musi byt kladne cislo!");
            alert.showAndWait();
        }
    }

    public void setScale(float scale) {
        this.scale = scale;
    }

    public float getScale() {
        return scale;
    }


    /**
     * Předá GUI elementy na vykreslování.
     * @param elements Elementy, které se vykreslí na mapu.
     */
    public void setElements(List<drawable> elements) {
        this.elements = elements;
        //elements.remove(elements.size() - 1);
        //System.out.println(elements);
        for (drawable drawable : elements) {
            //System.out.println(drawable);
            content.getChildren().addAll(drawable.getGUI());
            //System.out.println(drawable.getGUI());
            if (drawable instanceof TimeUpdate) {
                //System.out.println(drawable);
                cars.add((TimeUpdate) drawable);
            }
        }
    }

    /**
     * Předá GUI elementy na vykreslování.
     * @param elements Elementy, které se vykreslí na mapu.
     */
    public void setElements2(List<drawable> elements) {
        this.elements = elements;
        //elements.remove(elements.size() - 1);
        //System.out.println(elements);
        for (drawable drawable : elements) {
            //System.out.println(drawable);
            button1.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent t) {
                    //System.out.println("AHOJ");
                    for (drawable drawable : elements) {
                        content.getChildren().addAll(drawable.getGUI1());

                    }
                }
            });
            content.getChildren().addAll(drawable.getGUI());
            ulice.add(drawable);
        }
    }

    public void setElements20(List<drawable> elements) {
        this.elements = elements;
        //elements.remove(elements.size() - 1);
        //System.out.println(elements);
        for (drawable drawable : elements) {
            //System.out.println(drawable);
            content.getChildren().addAll(drawable.getGUI());
            button2.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent t) {
                    //System.out.println("AHOJ");
                    for (drawable drawable : elements) {
                        content.getChildren().addAll(drawable.getGUI1());
                    }
                }
            });
            //System.out.println(drawable);
            ulice.add(drawable);
        }
    }

    public void setElements21(List<drawable> elements) {
        this.elements = elements;
        //elements.remove(elements.size() - 1);
        //System.out.println(elements);
        for (drawable drawable : elements) {
            //System.out.println(drawable);
            content.getChildren().addAll(drawable.getGUI());
            button3.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent t) {
                    //System.out.println("AHOJ");
                    for (drawable drawable : elements) {
                        content.getChildren().addAll(drawable.getGUI1());
                    }
                }
            });

            ulice.add(drawable);
        }
    }


    public void setElements3(List<drawable> elements) {
        this.elements = elements;
        //elements.remove(elements.size() - 1);
        //System.out.println(elements);
        for (drawable drawable : elements) {
            //System.out.println(drawable);
            content.getChildren().addAll(drawable.getGUI());
            if (drawable instanceof TimeUpdate) {
                //System.out.println(drawable);
                stops.add((TimeUpdate) drawable);
            }
        }
    }

    /**
     * Pracuje s časem, který ovlivňuje chování GUI. Udává, jak často se updatuje.
     * @param scale délka, po kterou se updatuje čas.
     */

    public void startTime(float scale) {
        List<TimeUpdate> god = new ArrayList<>();
        timer = new Timer(false);
        timer.scheduleAtFixedRate(new TimerTask() {
            // kazdou sekundu to bude volat run()
            @Override
            public void run() {
                Platform.runLater(() -> {
                    try {
                        time = time.plusSeconds(1);
                        for (TimeUpdate update : cars) {
                            //System.out.println(time);
                            update.update(time);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }
        }, 0, (long) (1000 / scale));    // zrychleni casu se dela kdyz navisime update o 1 sekundu, cim nizsi tim lepsi
        //timer.schedule(, 2000, 2000);
    }



}
