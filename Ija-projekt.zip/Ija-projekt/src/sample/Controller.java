package sample;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

import java.sql.Time;
import java.time.LocalTime;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

/**Reprezentuje třídu, která pracuje s GUI a zapisuje do něj.
 * @author Matěj Krátký, Petr Červinka
 */

public class Controller {
    public Label napis1;
    public AnchorPane spodek;

    public Label napis11;
    public Label napis12;
    public Label napis13;
    public Button button1;
    public Button button2;
    public Button button3;
    public TextField Cas;
    public Button buttonTime;
    public Button buttonZpomaleni;
    public TextField zpomaleni;
    public TextField zpomal;
    public Button buttonZastav;
    @FXML
    private Pane content;

    @FXML
    private TextField TimeScale;
    // list elementu, ktere zobrazujeme na mapu
    private List<drawable> elements = new ArrayList<>();
    private List<TimeUpdate> streets = new ArrayList<>();
    private List<drawable> ulice = new ArrayList<>();
    private List<TimeUpdate> cars1 = new ArrayList<>();
    private List<TimeUpdate> cars2 = new ArrayList<>();
    private List<TimeUpdate> cars3 = new ArrayList<>();
    private List<TimeUpdate> objezd = new ArrayList<>();
    private List<TimeUpdate> stops = new ArrayList<>();
    private List<String> times = new ArrayList<>();
    public Timer timer;
    private float scale;
    private String cas;
    Queue<TimeUpdate> car_queue = new LinkedList<>();
    TimeUpdate stop;
    private int pocitadlo = 0;
    private LocalTime time = LocalTime.now();
    AtomicInteger hodina = new AtomicInteger();
    AtomicInteger minuta = new AtomicInteger();
    javafx.scene.paint.Color color;
    javafx.scene.paint.Color[] colors = new javafx.scene.paint.Color[] {javafx.scene.paint.Color.BLACK, javafx.scene.paint.Color.RED};
    javafx.scene.paint.Color[] colors1 = new javafx.scene.paint.Color[] {javafx.scene.paint.Color.BLACK, javafx.scene.paint.Color.GREEN};
    AtomicInteger cislo = new AtomicInteger();

    /**
     * Zvětšuje a zmenšuje mapu.
     * @param event událost(scroll).
     */

    @FXML
    private void onZoom (ScrollEvent event) {
        event.consume();
        double zoom = event.getDeltaY() > 0 ? 1.1 : 0.9;
        content.setScaleX(zoom * content.getScaleX());
        content.setScaleY(zoom * content.getScaleY());
    }

    public void Zpomal(ActionEvent actionEvent) {
        try {
            int zpomaleni = Integer.parseInt(TimeScale.getText());
            //napis11.textProperty().set("Rychlost similace: " + (int)scale + "x");
            if (scale <= 0) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Zvolena hodnota musi byt kladne cislo!");
                alert.showAndWait();
                return;
            }
            for (TimeUpdate auto : cars1) {
                ((Vehicle)auto).setSpeed(zpomaleni);
            }
            for (TimeUpdate auto : cars2) {
                ((Vehicle)auto).setSpeed(zpomaleni);
            }
            for (TimeUpdate auto : cars3) {
                ((Vehicle)auto).setSpeed(zpomaleni);
            }
        }
        catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Zvolena hodnota musi byt kladne cislo!");
            alert.showAndWait();
        }

    }

    public void zastavUlici(ActionEvent actionEvent) {
        for (drawable ulica : ulice) {
            ((Street)ulica).getLine().setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    //System.out.println("ahoj");
                    Platform.runLater(() -> {
                        try {
                            if (cislo.get() < ((colors1.length) - 1)) {
                                cislo.getAndIncrement();
                                ((Street)ulica).getLine().setStrokeWidth(2);
                            }
                            else {
                                cislo.set(0);
                                ((Street)ulica).getLine().setStrokeWidth(1);
                            }
                            int i = cislo.intValue();
                            ((Street)ulica) .getLine().setStroke(colors1[i]);
                            if (colors1[i] == javafx.scene.paint.Color.GREEN) {
                                System.out.println(ulica);
                                if (((Street) ulica).getId().equals("TestStreet")) {
                                    System.out.println(((Vehicle)cars1.get(0)).getPath().getPath());
                                    ((Vehicle)cars1.get(0)).getPath().getPath().get(0).setX(300);
                                    ((Vehicle)cars1.get(0)).getPath().getPath().get(0).setY(300);
                                    ((Vehicle)cars1.get(1)).getPath().getPath().get(0).setX(500);
                                    ((Vehicle)cars1.get(2)).getPath().getPath().get(0).setY(300);
                                }
                            }
                            else {
                                //sc = sc_remembered;
                                ((Street)ulica).getLine().setStrokeWidth(1);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    });
                }
            });
        }
    }

    public void chooseTime() {
        String cas = Cas.getText();
        String[]pole_cas = cas.split(":", 2);
        try {
            hodina.set(Integer.parseInt(pole_cas[0]));
            minuta.set(Integer.parseInt(pole_cas[1]));
        } catch (Exception e) {
            e.printStackTrace();
        }
        timer = new Timer(false);
        AtomicReference<Float> timee = new AtomicReference<>((float)1000);
        AtomicReference<Float> sc = new AtomicReference<>(getScale());
        AtomicReference<Float> sc_remembered = new AtomicReference<>(getScale());
        sc_remembered = sc;
        if (sc.get() == 0) {
            sc.set((float) 1);
            sc_remembered = sc;
        }
        timer.scheduleAtFixedRate(new TimerTask() {
            // kazdou sekundu to bude volat run()
            @Override
            public void run() {
                Platform.runLater(() -> {

                    try {
                        //System.out.println(streets);
                        if (Integer.parseInt(pole_cas[0]) >= 0 || Integer.parseInt(pole_cas[0]) <= 23) {
                            minuta.getAndIncrement();
                            if (minuta.intValue() > 59) {
                                minuta.set(0);
                                hodina.getAndIncrement();
                            }
                            if (hodina.intValue() > 23) {
                                hodina.set(0);
                            }
                            //System.out.println(hodina + ":" + minuta);
                            setCas(hodina + ":" + minuta);
                        }
                        else {
                            Alert alert = new Alert(Alert.AlertType.ERROR, "Zadany cas neexistuje!");
                            alert.showAndWait();
                            return;
                        }

                        for (drawable ulica : ulice) {
                            ((Street)ulica).getLine().setOnMouseClicked(new EventHandler<MouseEvent>() {
                                @Override
                                public void handle(MouseEvent mouseEvent) {
                                    //System.out.println("ahoj");
                                    Platform.runLater(() -> {
                                        try {
                                            if (cislo.get() < ((colors.length) - 1)) {
                                                cislo.getAndIncrement();
                                                ((Street)ulica).getLine().setStrokeWidth(2);
                                            }
                                            else {
                                                cislo.set(0);
                                                ((Street)ulica).getLine().setStrokeWidth(1);
                                            }
                                            int i = cislo.intValue();
                                            ((Street)ulica) .getLine().setStroke(colors[i]);
                                            if (colors[i] == javafx.scene.paint.Color.RED) {

                                            }
                                            else {
                                                //sc = sc_remembered;
                                                ((Street)ulica).getLine().setStrokeWidth(1);
                                            }
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    });
                                }
                            });
                            if (((Street) ulica).getLine().getStroke() == colors[1]) {
                                //System.out.println(((Vehicle)cars.get(0)).getPosition());
                                for (TimeUpdate auto : cars1) {
                                    if (((Vehicle)auto).getPosition().getX() < (((Street) ulica).getCoordinates()).get(0).getX() && ((Vehicle)auto).getPosition().getX() > (((Street) ulica).getCoordinates()).get(1).getX()) {
                                        if (((Vehicle)auto).getPosition().getY() > (((Street) ulica).getCoordinates()).get(0).getY() && ((Vehicle)auto).getPosition().getY() < (((Street) ulica).getCoordinates()).get(1).getY()) {
                                            ((Vehicle)auto).setSpeed(2);
                                        }
                                    }
                                    else if (((Vehicle)auto).getPosition().getX() > (((Street) ulica).getCoordinates()).get(0).getX() && ((Vehicle)auto).getPosition().getX() < (((Street) ulica).getCoordinates()).get(1).getX()) {
                                        if ((((Street) ulica).getCoordinates()).get(0).getY() == (((Street) ulica).getCoordinates()).get(1).getY()) {
                                            ((Vehicle)auto).setSpeed(2);
                                        }
                                    }
                                    else if (Math.round(((Vehicle)auto).getPosition().getX()) == ((((Street) ulica).getCoordinates()).get(1).getX()) - 1) {
                                        System.out.println(Math.round(((Vehicle)auto).getPosition().getX()));
                                        System.out.println(((((Street) ulica).getCoordinates()).get(1).getX()) - 1);
                                        if (((Vehicle)auto).getPosition().getY() < (((Street) ulica).getCoordinates()).get(0).getY() && ((Vehicle)auto).getPosition().getY() > (((Street) ulica).getCoordinates()).get(1).getY()) {
                                            ((Vehicle)auto).setSpeed(2);
                                        }
                                    }
                                    else {
                                        ((Vehicle)auto).setSpeed(8);
                                    }
                                }
                            }


                        }
                        //for (TimeUpdate update : car_queue) {
                        int cislo = 0;
                        for (int i = 0; i < cars1.size() - 1; i++) {
                            int finalI = i;
                            int finalCislo = cislo;
                            Platform.runLater(() -> {
                                try {
                                    new java.util.Timer().schedule(
                                            new java.util.TimerTask() {
                                                @Override
                                                public void run() {
                                                    cars1.get(finalI).update(time);
                                                    cars2.get(finalI).update(time);
                                                    cars3.get(finalI).update(time);
                                                }
                                            },
                                            finalCislo
                                    );
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            });
                            cislo += 15000;
                        }
                        //setScale1();
                        //setScale2();
                        //setScale3();


                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }
        }, 0, (long) (1000 / sc.get()));
    }

    public void setCas(String cas) {
        this.cas = cas;
    }

    public String getCas() {
        return cas;
    }

    public List<TimeUpdate> getCars() {
        return cars1;
    }

    /**
     * Práce s časem v GUI.
     */

    @FXML
    private void onTimeScaleChange() {
        try {
            float scale = Float.parseFloat(TimeScale.getText());
            napis1.textProperty().set("Rychlost simulace: " + (int)scale + "x");
            //napis11.textProperty().set("Rychlost similace: " + (int)scale + "x");
            if (scale <= 0) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Zvolena hodnota musi byt kladne cislo!");
                alert.showAndWait();
                return;
            }
            //timer.cancel();
            setScale(scale);
            //startTime(scale);
        }
        catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Zvolena hodnota musi byt kladne cislo!");
            alert.showAndWait();
        }
    }

    public void setScale(float scale) {
        this.scale = scale;
    }

    public float getScale() {
        return scale;
    }


    /**
     * Předá GUI elementy na vykreslování.
     * @param elements Elementy, které se vykreslí na mapu.
     */
    public void setElements(List<drawable> elements) {
        //System.out.println(elements);
        this.elements = elements;
        //elements.remove(elements.size() - 1);
        //System.out.println(elements);
        for (drawable drawable : elements) {
            //System.out.println(drawable);
            content.getChildren().addAll(drawable.getGUI());
            //System.out.println(drawable.getGUI());
            if (drawable instanceof TimeUpdate) {
                cars1.add((TimeUpdate) drawable);
                car_queue.add((TimeUpdate) drawable);
            }
        }
    }

    /**
     * Předá GUI elementy na vykreslování.
     * @param elements Elementy, které se vykreslí na mapu.
     */
    public void setElementss(List<drawable> elements) {
        //System.out.println(elements);
        this.elements = elements;
        //elements.remove(elements.size() - 1);
        //System.out.println(elements);
        for (drawable drawable : elements) {
            //System.out.println(drawable);
            content.getChildren().addAll(drawable.getGUI());
            //System.out.println(drawable.getGUI());
            if (drawable instanceof TimeUpdate) {
                cars2.add((TimeUpdate) drawable);
                car_queue.add((TimeUpdate) drawable);
            }
        }
    }

    /**
     * Předá GUI elementy na vykreslování.
     * @param elements Elementy, které se vykreslí na mapu.
     */
    public void setElementsss(List<drawable> elements) {
        //System.out.println(elements);
        this.elements = elements;
        //elements.remove(elements.size() - 1);
        //System.out.println(elements);
        for (drawable drawable : elements) {
            //System.out.println(drawable);
            content.getChildren().addAll(drawable.getGUI());
            //System.out.println(drawable.getGUI());
            if (drawable instanceof TimeUpdate) {
                cars3.add((TimeUpdate) drawable);
                car_queue.add((TimeUpdate) drawable);
            }
        }
    }

    /**
     * Předá GUI elementy na vykreslování.
     * @param elements Elementy, které se vykreslí na mapu.
     */
    public void setElements2(List<drawable> elements) {
        this.elements = elements;
        //elements.remove(elements.size() - 1);
        //System.out.println(elements);
        for (drawable drawable : elements) {
            //System.out.println(drawable);
            button1.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent t) {
                    //System.out.println("AHOJ");
                    for (drawable drawable : elements) {
                        content.getChildren().addAll(drawable.getGUI1());

                    }
                }
            });
            content.getChildren().addAll(drawable.getGUI());
            ulice.add(drawable);
        }
    }

    public void setElements20(List<drawable> elements) {
        this.elements = elements;
        //elements.remove(elements.size() - 1);
        //System.out.println(elements);
        for (drawable drawable : elements) {
            //System.out.println(drawable);
            content.getChildren().addAll(drawable.getGUI());
            button2.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent t) {
                    //System.out.println("AHOJ");
                    for (drawable drawable : elements) {
                        content.getChildren().addAll(drawable.getGUI1());
                    }
                }
            });
            //System.out.println(drawable);
            ulice.add(drawable);
        }
    }

    public void setElements21(List<drawable> elements) {
        this.elements = elements;
        //elements.remove(elements.size() - 1);
        //System.out.println(elements);
        for (drawable drawable : elements) {
            //System.out.println(drawable);
            content.getChildren().addAll(drawable.getGUI());
            button3.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent t) {
                    //System.out.println("AHOJ");
                    for (drawable drawable : elements) {
                        content.getChildren().addAll(drawable.getGUI1());
                    }
                }
            });

            ulice.add(drawable);
        }
    }


    public void setElements3(List<drawable> elements) {
        this.elements = elements;
        //elements.remove(elements.size() - 1);
        //System.out.println(elements);
        for (drawable drawable : elements) {
            //System.out.println(drawable);
            content.getChildren().addAll(drawable.getGUI());
            if (drawable instanceof TimeUpdate) {
                //System.out.println(drawable);
                stops.add((TimeUpdate) drawable);
            }
        }
    }

    /**
     * Pracuje s časem, který ovlivňuje chování GUI. Udává, jak často se updatuje.
     * @param scale délka, po kterou se updatuje čas.
     */

    public void startTime(float scale) {
        List<TimeUpdate> god = new ArrayList<>();
        timer = new Timer(false);
        timer.scheduleAtFixedRate(new TimerTask() {
            // kazdou sekundu to bude volat run()
            @Override
            public void run() {
                Platform.runLater(() -> {
                    try {
                        time = time.plusSeconds(1);
                        for (TimeUpdate update : cars1) {
                            //System.out.println(time);
                            update.update(time);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }
        }, 0, (long) (1000 / scale));    // zrychleni casu se dela kdyz navisime update o 1 sekundu, cim nizsi tim lepsi
        //timer.schedule(, 2000, 2000);
    }

    public void setScale1() {
        int cislo = 0;
        for (int i = 0; i < cars1.size() - 1; i++) {
            int finalI = i;
            int finalCislo = cislo;
            Platform.runLater(() -> {
                try {
                    new java.util.Timer().schedule(
                            new java.util.TimerTask() {
                                @Override
                                public void run() {
                                    cars1.get(finalI).update(time);
                                }
                            },
                            finalCislo
                    );
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            cislo += 15000;
        }
    }

    public void setScale2() {
        int cislo = 3000;
        for (int i = 0; i < cars2.size() - 1; i++) {
            int finalI = i;
            int finalCislo = cislo;
            Platform.runLater(() -> {
                try {
                    new java.util.Timer().schedule(
                            new java.util.TimerTask() {
                                @Override
                                public void run() {
                                    cars2.get(finalI).update(time);
                                }
                            },
                            finalCislo
                    );
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            cislo += 10000;
        }
    }

    public void setScale3() {
        int cislo = 1000;
        for (int i = 0; i < cars3.size() - 1; i++) {
            int finalI = i;
            int finalCislo = cislo;
            Platform.runLater(() -> {
                try {
                    new java.util.Timer().schedule(
                            new java.util.TimerTask() {
                                @Override
                                public void run() {
                                    cars3.get(finalI).update(time);
                                }
                            },
                            finalCislo
                    );
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            cislo += 16000;
        }
    }

}
