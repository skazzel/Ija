package sample;

import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Control;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;
import javafx.application.Platform;
import sample.Controller;
import sample.TimeUpdate;
import sample.drawable;

import java.util.ArrayList;
import java.util.List;

/**
 * Reprezentuje zastávku. Zastávka má svůj unikátní identifikátor a dále souřadnice umístění a zná ulici, na které je umístěna.
 * Zastávka je jedinečná svým identifikátorem. Reprezentace zastávky může existovat, ale nemusí mít
 * přiřazeno umístění (tj. je bez souřadnic a bez znalosti ulice). Pro shodu objektů platí, že dvě zastávky jsou shodné, pokud
 * mají stejný identifikátor.
 * @author Matěj Krátký, Petr Červinka
 */

public class Stop implements drawable{
    private List<Shape> gui;
    private List<Shape> gui1;
    private Coordinate position;
    Street street;
    String id;
    private String nazev, linka;
    Circle circle;
    Color colour;

    public Stop(String id, Coordinate position, String color, Stage primaryStage) throws Exception{
        this.position = position;
        this.id = id;
        gui = new ArrayList<>();
        gui1 = new ArrayList<>();

        FXMLLoader loader = new FXMLLoader(getClass().getResource("sample.fxml"));
        loader.getController();
        Controller controller = loader.getController();

        if (color.equals("orange")) {
            colour = Color.ORANGE;
            circle = new Circle(position.getX(), position.getY(), 3, colour);
            gui.add(circle);
        }
        else if (color.equals("purple")) {
            colour = Color.PURPLE;
            circle = new Circle(position.getX(), position.getY(), 3, colour);
            gui.add(circle);
        }
        else if (color.equals("green")) {
            colour = Color.GREEN;
            circle = new Circle(position.getX(), position.getY(), 3, colour);
            gui.add(circle);
        }

    }

    public Coordinate getPosition() {
        return position;
    }

    /**
     * Vrací barvu zastavky.
     * @return barva zastavky.
     */
    public Color getColor() {
        return colour;
    }

    /**
     * Nastavuje parametry kruhu..
     */
    public void setCircle() {
        this.circle = new Circle(position.getX(), position.getY(), 3, Color.PURPLE);
    }

    public Circle getCircle() {
        return circle;
    }

    /**
     * Vrací pozici zastávky z GUI.
     * @return zastávka na mapě.
     */
    @Override
    public List<Shape> getGUI() {
        return gui;
    }

    /**
     * Vrací pozici zastávky z GUI1.
     * @return zastávka na mapě.
     */
    @Override
    public List<Shape> getGUI1() {
        return gui;
    }


    /**
     * Nastaví ulici, na které je zastávka umístěna.
     * @param s Ulice, na které je zastávka umístěna.
     */
    public void setStreet(Street s) {
        this.street = s;
    }

    /**
     * Vrátí ulici, na které je zastávka umístěna.
     * @return Ulice, na které je zastávka umístěna. Pokud zastávka existuje, ale dosud nemá umístění, vrací null.
     */
    public Street getStreet() {
        return street;
    }

    /**
     * Vrátí pozici zastávky.
     * @return Pozice zastávky. Pokud zastávka existuje, ale dosud nemá umístění, vrací null.
     */
    public Coordinate getCoordinate() {
        return position;
    }

    @Override
    public String toString() {
        return "Stop{" +
                "position=" + position +
                '}';
    }
}