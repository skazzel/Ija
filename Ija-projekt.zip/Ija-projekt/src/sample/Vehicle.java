package sample;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Shape;
import javafx.scene.shape.Circle;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
/** Reprezentuje jedno vozidlo, které se pohybuje po trase určitou rychlostí
 * @author Matěj Krátký, Petr Červinka
 */
public class Vehicle implements drawable, TimeUpdate {
    private Coordinate position;
    private double speed = 3;
    private List<Shape> gui;
    private List<Shape> gui1;
    private int distance = 0;
    private Path path;
    javafx.scene.paint.Color color;
    List<Coordinate> souradnice = new ArrayList<>();
    Circle circle;

    public Vehicle(String id, Coordinate position, double speed, Path path) {
        this.position = position;
        this.speed = speed;
        this.path = path;
        gui = new ArrayList<>();
        circle = new Circle(position.getX(), position.getY(), 6, Color.BLUE);
        gui.add(circle);
        gui1 = new ArrayList<>();
    }

    public javafx.scene.paint.Color getColor() {
        return color;
    }

    public Circle getCircle() {
        return circle;
    }

    /**
     * Posune GUI o určitou pozici vůči mapě.
     * @param coordinate Souřadnice, ke které vozidlo jede.
     */
    private void moveGUI(Coordinate coordinate) {
        for (Shape shape : gui) {
            shape.setTranslateX(coordinate.getX() - position.getX() + shape.getTranslateX());
            shape.setTranslateY(coordinate.getY() - position.getY() + shape.getTranslateY());
        }
    }

    /**
     * Vrátí cestu vozidla.
     * @return cesta vozidla.
     */
    public Path getPath() {
        return path;
    }

    @Override
    public List<Shape> getGUI() {
        return gui;
    }

    @Override
    public List<Shape> getGUI1() {
        return gui1;
    }

    /**
     * Aktualizuje mapu za určitý čas. Funkce pohybuje vozidlem.
     * @param time čas, při kterém se funkce provádí.
     */
    @Override
    public void update(LocalTime time) {
        distance += speed;
        if (distance > path.getPathSize()) {
            return;
        }
        Coordinate coords = path.getCoordinateByDistance(distance);
        //System.out.println(coords);
        moveGUI(coords);
        position = coords;
    }

    /**
     * Vrací aktuální pozici vozidla.
     * @return pozice vozidla.
     */
    public Coordinate getPosition() {
        return position;
    }

    /**
     * Vytvoří novou pozici vozidla.
     * @param position Nová pozice vozidla.
     */
    public void setPosition(Coordinate position) {
        this.position = position;
    }

    /**
     * Vytvoří novou rychlost vozidla.
     * @param speed Nová rychlost vozidla.
     */
    public void setSpeed(double speed) {
        this.speed = speed;
    }

    /**
     * Vrací aktuální rychlost vozidla.
     * @return rychlost vozidla.
     */
    public double getSpeed() {
        return speed;
    }

    @Override
    public String toString() {
        return "Vehicle{" +
                "position=" + position +
                ", speed=" + speed +
                '}';
    }
}
