package sample;
import java.lang.Math;

/**
 * Reprezentuje pozici (souřadnice) v mapě. Souřadnice je dvojice (x,y), počátek mapy je vždy na pozici (0,0).
 * Nelze mít pozici se zápornou souřadnicí.
 * @author Matěj Krátký, Petr Červinka
 */
public class Coordinate {
    private double x;
    private double y;


    public Coordinate (double x, double y){
        this.x = x;
        this.y = y;
    }


    // vytvori coordinate
    public static Coordinate create (double x, double y){
        if (x >= 0 && y >= 0) {
			Coordinate coo = new Coordinate(x, y);
			return coo;
		}
		else {
			return null;
		}
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y) {
        this.y = y;
    }

    /**
     * Vrací hodnotu souřadnice x.
     * @return Souřadnice x.
     */
    public double getX(){
        return x;
    }

    /**
     * Vrací hodnotu souřadnice y.
     * @return Souřadnice y.
     */
    public double getY() {
        return y;
    }

    /**
     * Vrací rozdíl souřadnic x.
     * @param c Souřadnice bodu, se kterým chceme pracovat.
     * @return rozdíl souřadnic x.
     */
    public double diffX(Coordinate c) {
        return Math.abs(this.x - c.x);
    }
    /**
     * Vrací rozdíl souřadnic y.
     * @param c Souřadnice bodu, se kterým chceme pracovat.
     * @return Souřadnice y.
     */
    public double diffY(Coordinate c) {
        return Math.abs(this.y - c.y);
    }

    /**
     * Kontroluje, jestli se koordináty rovnají.
     * @param o Objekt, se kterým chceme pracovat.
     * @return true, pokud se rovnají/false, pokud se nerovnají.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o ) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Coordinate coo = (Coordinate) o;
        if (x == coo.getX() && y == coo.getY()) {
        	return true;
        }
        return false;
    }

    /**
     * Kontroluje, zda souřadnice leží na přímce(bod na ulici).
     * @param target Souřadnice zastávky.
     * @param to Souřadnice konce ulice.
     * @return true, pokud leží na ulici/false, pokud neleží na ulici.
     */
    public boolean belongs(Coordinate target, Coordinate to){
        double newX = target.x - this.x;
        double newY = target.y - this.y;
        double subX = to.x - this.x;
        double subY = to.y - this.y;

        if (newX / subX == newY / subY){
            if (newX / subX < 0.0 || newX / subX > 1.0){
                return false;
            }
            return true;
        }
        if (diffX(target) == 0 && to.diffX(target) == 0)
            if (Math.abs(target.diffY(this)) <= Math.abs(diffY(to)) && Math.abs(target.diffY(to)) <= Math.abs(to.diffY(this)))
                return true;
        if (diffY(target) == 0 && to.diffY(target) == 0)
            if (Math.abs(target.diffX(this)) <= Math.abs(diffX(to)) && Math.abs(target.diffX(to)) <= Math.abs(to.diffX(this)))
                return true;
        return false;
    }

    @Override
    public String toString() {
        return "Coordinate{" +
                "x=" + x +
                ", y=" + y +
                '}';
    }
}