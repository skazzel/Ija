package sample;

import java.util.List;

/**Reprezentuje cestu, kterou jede vozidlo. Počítá vzdálenost mezi souřadnicemi a jejich cestu.
 * @author Matěj Krátký, Petr Červinka
 */

public class Path {
    List<Coordinate> path;

    public Path(List<Coordinate> path) {
        this.path = path;
    }

    /**
     * Vypočítá vzálenost mezi zadanými souřadnicemi.
     * @param a První souřadnice
     * @param b Druhá souřadnice
     * @return Vzdálenost mezi souřadnicemi "a" a "b".
     */
    private double getDistanceBetweenCoordinate(Coordinate a, Coordinate b) {
        /*
        float angle = (float) Math.toDegrees(Math.atan2(a.getY() - b.getY(), a.getX() - b.getX()));
        if(angle < 0){
            angle += 360;
        }
        */
        //System.out.println(a.getX() + " " + a.getY());
        //System.out.println(b.getX() + " " + b.getY());
        if (Math.sqrt((a.getX() - b.getX()) * (a.getX() - b.getX()) + (a.getY() - b.getY()) * (a.getY() - b.getY())) < 0) {
            //System.out.println(Math.sqrt((b.getX() - a.getX()) * (b.getX() - a.getX()) + (b.getY() - a.getY()) * (b.getY() - a.getY())));
            return Math.sqrt((b.getX() - a.getX()) * (b.getX() - a.getX()) + (b.getY() - a.getY()) * (b.getY() - a.getY()));
        }
        //System.out.println(Math.sqrt((b.getX() - a.getX()) * (b.getX() - a.getX()) + (b.getY() - a.getY()) * (b.getY() - a.getY())));
        return Math.sqrt((a.getX() - b.getX()) * (a.getX() - b.getX()) + (a.getY() - b.getY()) * (a.getY() - b.getY()));
    }
    /**
     * Získá koordináty pomocí vzdálenosti
     * @param distance vzdálenost,
     * @return Upravené posunuté koordináty o "distance".
     */

    public Coordinate getCoordinateByDistance(int distance) {
        double length = 0;
        double currentLength = 0;

        Coordinate a = null;
        Coordinate b = null;

        for (int i = 0; i < path.size() - 1; i++) {
            a = path.get(i);
            b = path.get(i + 1);
            currentLength = getDistanceBetweenCoordinate(a, b);

            if (length + currentLength >= distance) {
                //System.out.println("KONEC");
                break;
            }
            length += currentLength;
        }
        if (a == null || b == null) {
            return null;
        }
        double driven = (distance - length) / currentLength;
        //System.out.println(driven);
        return new Coordinate(a.getX() + (b.getX() - a.getX()) * driven, a.getY() + (b.getY() - a.getY()) * driven);
    }

    /**
     * Získá velikost/délku cesty.
     * @return Velikost cesty.
     */
    public double getPathSize() {
        double size = 0;
        for (int i = 0; i < (path.size() - 1); i++) {
            size += getDistanceBetweenCoordinate(path.get(i), path.get(i + 1));
        }
        return size;
    }

    @Override
    public String toString() {
        return "Path{" +
                "path=" + path +
                '}';
    }
}
