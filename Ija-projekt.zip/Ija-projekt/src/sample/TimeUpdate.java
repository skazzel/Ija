package sample;

import java.time.LocalTime;
/** Interface pro práci s časem
 * @author Matěj Krátký, Petr Červinka
 */

public interface TimeUpdate {
    void update(LocalTime time);
}
