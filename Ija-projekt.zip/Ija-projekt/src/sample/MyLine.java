package sample;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.AbstractMap.SimpleImmutableEntry;

/**Reprezentuje jednu linku hromadné dopravy. Každá linka má svůj jedinečný identifikátor,
 * seznam zastávek a seznam ulic, kterými projíždí. Ulice musí na sebe navazovat, na ulici,
 * kterou linka projíždí, nemusí být zastávka (příp. zastávka není součástí linky).
 * @author Matěj Krátký, Petr Červinka
 */

public class MyLine implements Line{
    private String id;
    private List<Stop> stops;
    private List<Street> streets;
    List <SimpleImmutableEntry<Street,Stop>> list;

    public MyLine (String id){
        this.id = id;
        this.list = new ArrayList <SimpleImmutableEntry<Street,Stop>>();
    }

    public boolean addStreet(Street street){

        if (list.isEmpty()) {
            return false;
        }
        else {
            Street streetos =list.get(list.size()-1).getKey();
            street.follows(streetos);
            if (!street.follows(streetos)) {
                return false;
            }
            else {
                list.add(new SimpleImmutableEntry<Street,Stop>(street,null));
                return true;
            }
        }
    }

    public boolean addStop(Stop stop){
        Street streetos=stop.getStreet();
        if(list.isEmpty()){
            list.add(new SimpleImmutableEntry<Street,Stop>(streetos,stop));
            return true;
        }
        else {
            SimpleImmutableEntry<Street,Stop> last=list.get(list.size()-1);
            Street last_adr=last.getKey();
            if(streetos!=null){
                if(streetos.follows(last_adr)){
                    list.add(new SimpleImmutableEntry<Street,Stop>(streetos,stop));
                    return true;
                } return false;
            }
            else{
                list.add(new SimpleImmutableEntry<Street,Stop>(streetos,stop));

                return true;
            }
        }
    }

    public List<SimpleImmutableEntry<Street, Stop>>getRoute(){
        List<SimpleImmutableEntry<Street,Stop>> all_list = Collections.unmodifiableList(list);
        return all_list;
    }

}