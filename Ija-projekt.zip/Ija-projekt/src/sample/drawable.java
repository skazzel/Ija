package sample;

import javafx.scene.shape.Shape;

import java.awt.*;
import java.util.List;

/** Interface pro práci s GUI
 * @author Matěj Krátký, Petr Červinka
 */

public interface drawable {
    List<Shape> getGUI();
    List<Shape> getGUI1();
    javafx.scene.paint.Color getColor();
}

