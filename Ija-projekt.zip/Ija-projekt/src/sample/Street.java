package sample;

import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Line;
import javafx.scene.shape.Shape;
import javafx.scene.text.Text;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;

import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Reprezentuje jednu ulici v mapě. Ulice má svůj identifikátor (název) a je definována souřadnicemi.
 * Na ulici se mohou nacházet zastávky.
 * @author Matěj Krátký, Petr Červinka
 */


public class Street implements drawable {
    FXMLLoader loader = new FXMLLoader(getClass().getResource("sample.fxml"));
    Parent root = loader.load();
    Controller controller = (Controller) loader.getController();

    private String id;
    //Controller controller;
    private List<Stop> list_stop = new ArrayList<>();
    public List<Line> list_lineColor = new ArrayList<>();
    private List<Coordinate> coordinates;
    javafx.scene.paint.Color color;
    javafx.scene.paint.Color[] colors = new javafx.scene.paint.Color[] {javafx.scene.paint.Color.BLACK, javafx.scene.paint.Color.RED};
    javafx.scene.paint.Color[] colors1 = new javafx.scene.paint.Color[] {javafx.scene.paint.Color.BLACK, javafx.scene.paint.Color.RED};
    AtomicInteger cislo = new AtomicInteger();

    Color colour;
    Line line;
    Line line1;
    public Street(String id, Coordinate... coordinates) throws IOException {
        this.coordinates = new ArrayList<Coordinate>(Arrays.asList(coordinates));
        this.id = id;
    }

    public List<Coordinate> getCoordinates() {
        return coordinates;
    }

    public Line getLine() {
        return line;
    }

    public String getId () {
        return id;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    /**
     * Vrací pozici ulic a názvů z GUI.
     * @return List ulic a názvů.
     */
    @Override
    public List<Shape> getGUI() {
        line = new Line(coordinates.get(0).getX(), coordinates.get(0).getY(), coordinates.get((coordinates.size()) - 1).getX(), coordinates.get((coordinates.size()) - 1).getY());
        line.setStrokeWidth(1);
        setLine(line);
        /*line.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                //System.out.println("ahoj");
                Platform.runLater(() -> {
                    try {
                        if (cislo.get() < ((colors.length) - 1)) {
                            cislo.getAndIncrement();
                            line.setStrokeWidth(2);
                        }
                        else {
                            cislo.set(0);
                            line.setStrokeWidth(1);
                        }
                        int i = cislo.intValue();
                        setColor(colors[i]);
                        line.setStroke(colors[i]);
                        if (colors[i] == javafx.scene.paint.Color.RED) {
                            list_lineColor.add(line);
                            /*controller.buttonZpomaleni.setOnMouseClicked(new EventHandler<MouseEvent>() {
                                @Override
                                public void handle(MouseEvent mouseEvent) {
                                    //System.out.println("ahoj");
                                    Platform.runLater(() -> {
                                        try {
                                            float scale = Float.parseFloat(controller.zpomal.getText());
                                            controller.setScale(scale);
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    });
                                }
                            });*//*
                        }
                        else {
                            line.setStrokeWidth(1);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }
        });*/
        return Arrays.asList(
                new Text(coordinates.get(0).getX() + (Math.abs(coordinates.get(0).getX() - coordinates.get((coordinates.size()) - 1).getX()) / 2), coordinates.get(0).getY() + (Math.abs(coordinates.get(0).getY() - coordinates.get((coordinates.size()) - 1).getY()) / 2), null),
                line
        );
    }

    public void lineColor() {

    }

    /**
     * Vrací pozici ulic a názvů z GUI1.
     * @return List ulic a názvů.
     */
    @Override
    public List<Shape> getGUI1() {
        line1 = new Line(coordinates.get(0).getX(), coordinates.get(0).getY(), coordinates.get((coordinates.size()) - 1).getX(), coordinates.get((coordinates.size()) - 1).getY());
        line1.setStrokeWidth(1);
        try {
            if (cislo.get() < ((colors.length) - 1)) {
                cislo.getAndIncrement();
            }
            else {
                cislo.set(0);
                //line.setStrokeWidth(1);
            }
            int i = cislo.intValue();
            setColor(colors1[i]);
            line1.setStroke(colors[i]);
            if (colors1[i] == javafx.scene.paint.Color.BLACK) {
                // neco
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        line1.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                //System.out.println("ahoj");
                Platform.runLater(() -> {
                    try {
                        if (cislo.get() < ((colors.length) - 1)) {
                            cislo.getAndIncrement();
                            line1.setStrokeWidth(2);
                        }
                        else {
                            cislo.set(0);
                            line1.setStrokeWidth(1);
                        }
                        int i = cislo.intValue();
                        setColor(colors[i]);
                        line1.setStroke(colors[i]);
                        if (colors[i] == javafx.scene.paint.Color.RED) {
                            //System.out.println(line);
                        }
                        else {
                            line1.setStrokeWidth(1);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }
        });
        return Arrays.asList(
                new Text(coordinates.get(0).getX() + (Math.abs(coordinates.get(0).getX() - coordinates.get((coordinates.size()) - 1).getX()) / 2), coordinates.get(0).getY() + (Math.abs(coordinates.get(0).getY() - coordinates.get((coordinates.size()) - 1).getY()) / 2), null),
                line1
        );
    }

    public void setColor(javafx.scene.paint.Color color) {
        this.color = color;
    }

    public javafx.scene.paint.Color getColor() {
        return color;
    }

    /**
     * Kontroluje, zda používaná ulice navazuje na zadanou ulici.
     * @param s Ulice, kterou chceme kontrolovat.
     * @return true, pokud na sebe navazují/false, pokud na sebe nenavazují.
     */
    public boolean follows(Street s) {

        if ((this.begin()).equals(s.begin()) || (this.end()).equals(s.end()) || (this.begin()).equals(s.end()) || (this.end()).equals(s.begin())) {
            return true;
        }
        return false;
    }
    /**
     * Vrátí začátek ulice.
     * @return Pozice začátku ulice.
     */

    public Coordinate begin() {
        return coordinates.get(0);
    }

    /**
     * Vrátí konec ulice.
     * @return Pozice konce ulice.
     */
    public Coordinate end() {
        return coordinates.get((coordinates.size()) - 1);
    }


    /**
     * Přidá na zadanou ulici zastávku. Pokud zastávka na ulici neleží, nic se neprovede
     * @param stop Zastávka, kterou chceme na ulici přidat.
     * @return true, pokud zastávka leží na ulici a přidá se/false, pokud zastávka neleží na ulici.
     */
    public boolean addStop(Stop stop){
        for (int i = 0; i < coordinates.size()-1; i++)
            if (coordinates.get(i).belongs(stop.getCoordinate(), coordinates.get(i+1))){
                list_stop.add(stop);
                stop.setStreet(this);
                return true;
            }
        return false;
    }

    /**
     * Vrací seznam zastávek na ulici.
     * @return Seznam zastávek na ulici.
     */
    public List<Stop> getStops(){
        return list_stop;
    }

    @Override
    public String toString() {
        return "Street{" +
                "start=" + coordinates.get(0) +
                ", stop=" + coordinates.get((coordinates.size()) - 1) +
                ", id='" + id + '\'' +
                '}';
    }
}
