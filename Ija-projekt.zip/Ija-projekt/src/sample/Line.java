/*
 * Projekt na IJA 2019/2020.
 * Matěj Krátký - xkratk17
 * Petr Červika - xcervi24
 */
package sample;

/**Reprezentuje jednu linku hromadné dopravy. Každá linka má svůj jedinečný identifikátor,
 * seznam zastávek a seznam ulic, kterými projíždí. Ulice musí na sebe navazovat, na ulici,
 * kterou linka projíždí, nemusí být zastávka (příp. zastávka není součástí linky).
 * @author Matěj Krátký, Petr Červinka
 */

public interface Line {

    /**
     * Přidá zastávku na linku.
     * @param stop Zastávka, která se přidává na linku.
     * @return true, pokud se povede přidat/false pokud se nepovede přidat
     */
    boolean addStop(Stop stop);

    /**
     * Přidá ulici na linku.
     * @param street Ulice, která se přidává na linku.
     * @return true, pokud se povede přidat/false pokud se nepovede přidat
     */
    boolean addStreet(Street street);

    /**
     * Získá seznam ulic a zastávek jedné linky
     * @return Seznam zastávek a ulic.
     */
    java.util.List<java.util.AbstractMap.SimpleImmutableEntry <Street,Stop>> getRoute();

    /**
     * Vytvoří novou defaultní linku.
     * @param id Identifikátor zastávky.
     * @return Nově vytvořená linka.
     */
    static Line defaultLine(java.lang.String id){
        return new MyLine(id);
    };
}
