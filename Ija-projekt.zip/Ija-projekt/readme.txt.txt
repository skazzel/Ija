Název: Aplikace pro zobrazení linek hromadné dopravy a sledování jejich pohybu
Členové týmu: Matěj Krátký, Petr Červinka
Akademický rok: 2019/2020
